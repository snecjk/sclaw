import { useEffect, useState } from 'react';
import { MessageProcessor } from '@a2ui/web_core/v0_9';
import { A2uiSurface } from '@a2ui/react/v0_9';
import actionRegistry from '../contracts/action-registry.v1.json';
import {
  executeAction,
  type ActionRegistry,
  type ActionResult,
} from './runtime/action-executor';
import { createLocalActionTransport, getHostCatalogs, resolveCatalogIds } from './runtime/catalog';
import {
  isPageId,
  loadPageMessages,
  pageIdFromLocation,
  setPageHash,
  type PageId,
} from './runtime/page-loader';

function createProcessor(
  pageId: PageId,
  onAction: (action: unknown) => void | Promise<void>,
) {
  const messages = resolveCatalogIds(loadPageMessages(pageId));
  const processor = new MessageProcessor(getHostCatalogs(), (action) => {
    void onAction(action);
  });
  processor.processMessages(messages as never);
  return processor;
}

function applyCustomerListResult(processor: MessageProcessor, result: ActionResult): void {
  if (!result.ok || result.actionId !== 'customer.list') return;
  const items =
    result.data &&
    typeof result.data === 'object' &&
    Array.isArray((result.data as { items?: unknown }).items)
      ? ((result.data as { items: Array<{ id?: string; name?: string }> }).items)
      : [];
  try {
    processor.processMessages([
      {
        version: 'v0.9',
        updateDataModel: {
          surfaceId: 'customer-list',
          path: '/',
          value: {
            keyword: '',
            placeholder: '客户名称',
            columns: [
              { title: '客户ID', dataIndex: 'id' },
              { title: '客户名称', dataIndex: 'name' },
            ],
            rows: items.map((item, index) => ({
              id: item.id ?? `row-${index}`,
              name: item.name ?? '',
            })),
            current: 1,
            pageSize: 10,
            total: items.length,
            loading: false,
          },
        },
      },
    ] as never);
  } catch {
    // Surface may not exist on other pages.
  }
}

export default function App() {
  const [pageId, setPageId] = useState<PageId>(() => pageIdFromLocation('home'));
  const [error, setError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [processor, setProcessor] = useState<MessageProcessor | null>(null);
  const [surfaces, setSurfaces] = useState<Array<{ id: string }>>([]);

  useEffect(() => {
    const onHash = () => {
      const next = pageIdFromLocation('home');
      setPageId((prev) => (prev === next ? prev : next));
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const registry = actionRegistry as ActionRegistry;
    let active: MessageProcessor | null = null;

    const handleAction = async (raw: unknown) => {
      const result = await executeAction(registry, raw);
      if (cancelled) return;

      // Do not render Action Runtime debug logs in the business preview.
      // Failures stay visible; success stays silent. Dev logs belong in SClaw workbench later.
      if (!result.ok) {
        setActionError(
          result.error
            ? `操作失败：${result.error}`
            : `操作失败：未找到动作「${result.actionId || 'unknown'}」`,
        );
      } else {
        setActionError(null);
      }

      if (result.ok && result.actionId === 'app.navigate') {
        const data = result.data as { context?: { pageId?: string } } | undefined;
        const target = data?.context?.pageId;
        if (typeof target === 'string' && isPageId(target)) {
          setPageHash(target);
          setPageId(target);
        }
        return;
      }

      if (active) applyCustomerListResult(active, result);
    };

    const transport = createLocalActionTransport(handleAction);

    try {
      active = createProcessor(pageId, (action) => transport.publishAction(action));
      if (cancelled) return;
      setProcessor(active);
      setSurfaces(Array.from(active.model.surfacesMap.values()));
      setError(null);
      setActionError(null);
    } catch (err) {
      if (cancelled) return;
      setProcessor(null);
      setSurfaces([]);
      setError(err instanceof Error ? err.message : String(err));
    }

    return () => {
      cancelled = true;
    };
  }, [pageId]);

  useEffect(() => {
    if (!processor) return;
    const sync = () => setSurfaces(Array.from(processor.model.surfacesMap.values()));
    const createdSub = processor.onSurfaceCreated(sync);
    const deletedSub = processor.onSurfaceDeleted(sync);
    return () => {
      createdSub.unsubscribe();
      deletedSub.unsubscribe();
    };
  }, [processor]);

  return (
    <div className="host-shell">
      <header className="host-header">
        <h1>__APP_TITLE__</h1>
      </header>

      {error ? <div className="host-error">{error}</div> : null}

      {actionError ? (
        <div className="host-error" role="alert">
          {actionError}
        </div>
      ) : null}

      {!error && surfaces.length === 0 ? (
        <div className="host-error">页面暂无内容，请稍后再试或联系助手检查页面配置。</div>
      ) : null}

      {surfaces.map((surface) => (
        <div className="host-surface" key={surface.id}>
          <A2uiSurface surface={surface as never} />
        </div>
      ))}
    </div>
  );
}
