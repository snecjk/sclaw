# A2UI 单仓应用模板

本模板 = **公司发布平台 Vite 工程底座** + **SClaw A2UI / antd Catalog 业务层**。

## 目录

| 路径 | 谁改 | 说明 |
|---|---|---|
| `src/pages/*.page.json` | AI / 业务（主战场） | A2UI v0.9 消息列表 |
| `contracts/` | AI / 业务 | action / intent 契约 |
| `src/catalog/antd-catalog.tsx` | 平台 | antd 白名单组件（AI 做查询页用） |
| `src/runtime/` | 平台 | 宿主、页面加载、Action Runtime |
| `docs/api/` | 业务补充 | 接口说明 |
| `vite.config.ts` / `tsconfig.json` | 平台 | 对齐公司发布平台构建（产物目录 `build/`） |

## 构建约定（公司发布平台）

- 开发默认端口：`3000`（SClaw 工作台启动时会覆盖端口）
- 生产构建产物：`build/`（`npm run build`）
- 路径别名：`@/*`、`$src/*` → `src/*`
- rollup 锁定：`4.62.2`（与公司模板一致）

未引入公司模板的 `react-router` / `vite-plugin-pages`：页面路由由 A2UI `page-loader` + hash 承担。

## AI 约定

用户说「做查询页（条件 + 表格 + 分页）」时，即使用户**不提 antd**，也应使用：

- `catalogId: "antd"`
- `AntdFilterBar` + `AntdTable` + `AntdPagination`

见 `contracts/intent-component-registry.v1.json` 与 `src/pages/customer-list.page.json`。

## 本地运行

```bash
npm install
npm run dev
```

## 构建

```bash
npm run build
```

产物输出到 `build/`。
